/*
 * Exported with BrandonTools v0.9
 * Invocation command was BrandonTools -mode4 start start.png 
 * Time-stamp: Wednesday 04/10/2013, 15:19:43
 * 
 * Image Information
 * -----------------
 * start.png 240@160
 * 
 * Quote/Fortune of the Day!
 * -------------------------
 * Anybody can win, unless there happens to be a second entry.  ~George Ade
 * 
 * Pennies from heaven find their way to your doorstep this year!
 * 
 * All bug reports / feature requests are to be sent to Brandon (brandon.whitehead@gatech.edu)
 */

#ifndef START_BITMAP_H
#define START_BITMAP_H

extern const unsigned short start[19200];
extern const unsigned short start_palette[255];
#define START_WIDTH 240
#define START_HEIGHT 160
#define START_PALETTE_SIZE 255

#endif