#GBA pacman

This is a GBA project in CS 2110. I wrote a pacman game in C. Besides basic logic for the game, I also wrote a min-heap and Dijkstra algorithm in this project for AI of the game. 

To compile, you need to install cs2110-tool and emulator. you can find installation package in this repository. Install i386 version for 32 bits system or amd64 version for 64 bits system. If there are dependency problems, do "sudo apt-get install -f" or fix them manually. After you finish installation, you can run "make vba" or "make wxvba" to compile and run the game. Press Enter to start the game. Blue ghost will follow you and red ghost goes randomly.