//Mingjun Xie
#ifndef NYANCAT_HEAD_BITMAP_H
#define NYANCAT_HEAD_BITMAP_H
extern const unsigned short Nyancat_Head[391];
#define NYANCAT_HEAD_WIDTH 23
#define NYANCAT_HEAD_HEIGHT 17
#endif
