// bmptoc.c
// Name: YUFENG WANG

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#define COLOR(red,green,blue) (red)|(green <<5)|(blue <<10);

// This is the array into which you will load the raw data from the file
// You don't have to use this array if you don't want to, but you will be responsible
// for any errors caused by erroneously using the stack or malloc if you do it a
// different way, incorrectly!
char data_arr[0x36 + 240 * 160 * 4];

int main(int argc, char *argv[]) {
	int numberofelements = 0x36 + 240 * 160 * 4; //define the number of elements
	// 1. Make sure the user passed in the correct number of arguments
	
	if (argc != 2) {
		printf("wrong number of arguments: %s\n", strerror(errno));
		return 0;	
	}

	// 2. Open the file. If it doesn't exist, tell the user and then exit

	char *filename = argv[1];
	FILE *file = fopen(filename, "r");
	if (file == NULL) {
		printf("File does not exist: %s\n", strerror(errno));
		return 0;		
	}

	// 3. Read the file into the buffer then close it when you are done
	
	fread(data_arr,1,numberofelements,file);
	fclose(file);

	// 4. Get the w and h of the image
	
	int w;
	int h;
	w = *(int*) (data_arr + 0x12);
	h = *(int*) (data_arr + 0x16);
	// 5. Create header file, and write header contents. Close it
	int len = strlen(filename);
	char newfilename1[len-4];
	for (int i = 0; i < len - 4; i++) {
		newfilename1[i] = filename[i];
	}

	newfilename1[len-4] = '\0';
	strcat(newfilename1,".h");
	FILE *newfile = fopen(newfilename1,"w");
	filename[len-4] = '\0';
	newfilename1[len-4] = '\0';
	char name[len-3];

	strcpy(name,newfilename1);
	for (int i = 0; i < len; i++) {
		name[i] = toupper(name[i]);
	}
	int size = (w) * (h);
	
	fprintf(newfile, "#define %s_WIDTH %d\n", name, w);
	fprintf(newfile, "#define %s_HEIGHT %d\n", name, h);
	fprintf(newfile, "const unsigned short %s_data[%d];", filename, size);
	fclose(newfile);
	// 6. Create C file, and write pixel data. Close it
	for (int i = 0; i < len - 4; i++) {
		newfilename1[i] = filename[i];
	}
	newfilename1[len-4] = '\0';
	strcat(newfilename1,".c");
	FILE *cfile = fopen(newfilename1, "w");
	filename[len - 4] = '\0';
	fprintf(cfile,"const unsigned short %s_data[%d] ={",filename,size);
	unsigned char green;	//color is exactly 8 bits
	unsigned char blue;
	unsigned char red;
	unsigned int originalcolor = 0x0000;
	unsigned short newcolor;
	int i = 0;
	for (int row = h-1; row >= 0; row--) {
		for (int col = 0; col <= w -1; col++){
				if (i % 8 == 0) {
					fprintf(cfile, "\n");
				}
				originalcolor = *((unsigned int*) (data_arr + 0x36 + (row*(w)+col)*4));
				blue = (char) ((originalcolor) & 0xFF);
				green = (char) ((originalcolor >> 8) & 0xFF);
				red = (char) ((originalcolor >>16) & 0xFF);
				blue = blue/8; //divide by 8 time
				green = green/8;
				red = red/8;
				newcolor = (red) | (green<<5) |(blue<<10); 
				fprintf(cfile,"0x%04X, ", newcolor);
				i++;
	
		}
	}
	fprintf(cfile,"\n};");
	fclose(cfile);
	return 0;
	
}


