/**
 * CS 2110 - Spring 2016 - Homework #10
 *
 * @author YUFENG WANG
 *
 * deque.c: Complete the functions!
 */

#include <stdlib.h>
#include <stdio.h>
#include "deque.h"

/* The node struct. Has a prev pointer, next pointer, and data. */
/* DO NOT DEFINE ANYTHING OTHER THAN WHAT'S GIVEN OR YOU WILL GET A ZERO */
/* Design consideration: Only this file should know about nodes */
/* Only this file should be manipulating nodes */
/* DO NOT TOUCH THIS DECLARATION, DO NOT PUT IT IN OTHER FILES */
typedef struct dnode
{
    struct dnode* prev; /* Pointer to previous node */
    struct dnode* next; /* Pointer to next node */
    void* data; /* User data */
} node;

/* Do not create any global variables here. Your deque library should obviously
 * work for multiple concurrent deques */

// This function is declared as static since you should only be calling this
// function from inside this file.
static node* create_node(void* data);

/** create_node
  *
  * Helper function that creates a node by allocating memory for it on the heap.
  * Be sure to set its pointers to NULL.
  *
  * @param data a void pointer to data the user wants to store in the deque
  * @return a node
  */
 node* create_node(void* data)
{
    node *newNode = (node*)malloc(sizeof(node));
    newNode -> prev = NULL;
    newNode -> next = NULL;
    newNode -> data = data;
   return newNode;
}

/** create_deque
  *
  * Creates a deque by allocating memory for it on the heap.
  * Be sure to initialize size to zero and head/tail to NULL.
  *
  * @return an empty deque
  */
deque* create_deque(void)
{
    /// @todo Implement changing the return value!
    deque* newdeque = malloc(sizeof(deque));
    newdeque -> size = 0;
    newdeque -> head = NULL;
    newdeque -> tail = NULL;
    return newdeque;
}

/** push_front
  *
  * Adds the data to the front of the deque.
  *
  * @param d a pointer to the deque structure.
  * @param data pointer to data the user wants to store in the deque.
  */
void push_front(deque *d, void *data)
{
  node* newNode = create_node(data);
  if(d==NULL) {
    free(newNode);
    return;
  }
  if (!d->size ||d->head == NULL) {
    d->tail= newNode;
    d->head = newNode;
    d->head->next= d->tail;
    d->head->prev = d->tail;
    d->size++;
  } else {
    newNode ->next = d->head;
    newNode ->prev = d->tail;
    d->head -> prev = newNode;
    d->head = newNode;
    d->size++;
  }

}

/** push_back
  *
  * Adds the data to the back of the deque.
  *
  * @param d a pointer to the deque structure.
  * @param data pointer to data the user wants to store in the deque.
  */
void push_back(deque *d, void *data)
{
  node* newNode = create_node(data);
  if(!d->size || d->tail == NULL) {
    d->tail= newNode;
    d->head = newNode;
/*    d->head->next= d->tail;
    d->head->prev = d->tail;*/
    d->tail->prev = d->head;
    d->tail->next = d->head;
    d->size++;
  } else {
    newNode->next = d->head;
    d->tail->next = newNode;
    newNode->prev = d->tail;
    d->head->prev= newNode;
    d->tail = newNode;
    d->size++;
  }
}

/** front
  *
  * Gets the data at the front of the deque
  * If the deque is empty return NULL.
  *
  * @param d a pointer to the deque
  * @return The data at the first node in the deque or NULL.
  */
void *front(deque *d) {
    /// @todo Implement changing the return value!
    /// @note you are returning the HEAD's DATA not the head node. Remember, the
    /// user should never deal with the deque nodes.
    if (d == NULL) {
      return NULL;
    } else {
      return d-> head-> data;
    }
}

/** back
  *
  * Gets the data at the "end" of the deque
  * If the deque is empty return NULL.
  *
  * @param d a pointer to the deque structure
  * @return The data at the last node in the deque or NULL.
  */
void *back(deque *d)
{
    if (d==NULL||(!d->size)) {
      return NULL;
    } else if(d->size == 1) {
      return d->head->data;
    } 
    else {
      return d->tail->data;
    }
}

/** get
  *
  * Gets the data at the specified index in the deque
  *
  * @param d a pointer to the deque structure
  * @param index 0-based, starting from the head.
  * @return The data from the specified index in the deque or NULL if index is
  *         out of range of the deque.
  */
void *get(deque *d, int index)
{

  if (d == NULL || (!d->size) || (index >= d->size)) {
      return NULL;
    }
  node* newNode = d -> head;
    /// @todo Implement changing the return value!
  for (int i = 0; i < index; i++){
      newNode = newNode-> next;
    }
    return newNode ->data;
}

/** contains
  *
  * Traverses the deque, trying to see if the deque contains some data.
  * Since non-NULL values are considered true, this can be used like a boolean
  *
  * The "data" parameter may not necessarily point to the same address as the
  * equal data you are returning from this function, it's just data which the
  * eq_func says is equal. For instance, if you have a deque of person structs:
  *   (Andrew, 26), (Nick, 24), (Collin, 23), (Marie, 23)
  * And you want to return any person whose age is 22, you could create a new
  * person struct (<NULL>, 24) with an eq_func that returns age == 24 and pass
  * that into this function as "data". contains() would then return (Nick, 24)
  *
  * If there are multiple pieces of data in the deque which are equal to the
  * "data" parameter, return any one of them.
  *
  * @param d a pointer to the deque structure
  * @param data The data, to see if it exists in the deque
  * @param eq_func A function written by the user that will tell if two pieces
  *                of data are equal. Returns 0 if equal, something else
  *                otherwise. Imagine subtracting two numbers.
  * @return The data contained in the deque, or NULL if it doesn't exist
  */
void *contains(deque *d, void *data, deque_eq eq_func) {
  if (d==NULL || data ==NULL || eq_func == NULL) {
    return NULL;
  }
  node *tmpNode = d ->head;
  //node *recordNode = d->head;
  for (int i = 0; i< d->size;i++) {
    if (!eq_func(data, tmpNode->data)) {
      return tmpNode->data;
    }
    tmpNode = tmpNode->next;
  }
  return NULL;
}

/*int eq_func(const void* a, const void* b) {
  return ;
}
*/
/** pop_front
  *
  * Removes the node at the front of the deque, and returns its data to the user
  *
  * @param d a pointer to the deque.
  * @return The data in the first node, or NULL if the deque is NULL or empty
  */
void *pop_front(deque *d)
{
    /// @todo Implement
    //struct node *tmpNode = d ->head;
    if(d==NULL||!d->size) {
      return NULL;
    } 
    node *newNode = d->head;
    d->head = d->head->next;
    d->head->prev = d->tail;
    d->tail->next = d->head;
    d->size = d->size - 1;
    void* dataa = newNode->data;
    free(newNode);
    return dataa;
    
}

/** pop_back
  *
  * Removes the node at the end of the deque, and returns its data to the user
  *
  * @param d a pointer to the deque.
  * @return The data in the first node, or NULL if the deque is NULL or empty
  */
void *pop_back(deque *d)
{
    /// @todo Implement
    if(d==NULL||!d->size) {
      return NULL;
    } 
    node *newNode = d->tail;
    d->tail->next = d->head;
    d->head->prev = d->tail->prev;
    d->tail = d->tail->prev;
    d->size = d->size - 1;
    void* dataa = newNode->data;
    free(newNode);
    return dataa;
    
}

/** copy_deque
  *
  * Create a new deque structure, new nodes, and new copies of the data by using
  * the copy function. Its implementation for any test structure must copy
  * EVERYTHING!
  *
  * @param d A pointer to the deque structure to make a copy of
  * @param copy_func A function pointer to a function that makes a copy of the
  *                  data that's being used in this deque, allocating space for
  *                  every part of that data on the heap. This is some function
  *                  you must write yourself for testing, tailored specifically
  *                  to whatever context you're using the deque for in your test
  * @return The deque structure created by copying the old one, or NULL if the
  *         structure passed in is NULL.
  */
deque* copy_deque(deque *d, deque_copy copy_func)
{
  /// @todo implement
  if (d==NULL){
    return NULL;
  }
  if (copy_func == NULL) {
    return NULL;
  }
  deque* newdeque = create_deque();
  node* newNode = d->head;
  int count = 0;
  while (count < d->size) {
    push_back(newdeque, copy_func(newNode->data));
    newNode = newNode->next;
    count++;
  }
  return newdeque;
  free(newNode);
}



/** size
  *
  * Gets the size of the deque
  *
  * @param d a pointer to the deque structure
  * @return The size of the deque
  */
int size(deque *d)
{
  if(d==NULL) {
    return 0;
  }
    ///@note simply return the size of the deque. It's that easy!
    return d -> size;
}

/** remove_if
  *
  * Removes all nodes whose data when passed into the predicate function returns
  * true
  *
  * @param d a pointer to the deque structure
  * @param pred_func a pointer to a function that when it returns true, it
  *                  should remove the element from the deque.
  * @param free_func a pointer to a function that is responsible for freeing the
  *                  node's data
  * @return the number of nodes that were removed.
  */


int remove_if(deque *d, deque_pred pred_func, deque_op free_func)
{
    /// @todo Implement changing the return value!
    /// @note remember to also free all nodes you remove.
    /// @note be sure to call pred_func on the NODES DATA to check if the node
    ///       needs to be removed.
    /// @note free_func is a function that is responsible for freeing the node's
    ///       data only.
    if (d==NULL || !d->size) {
      return 0;
    }
    int number = 0;
    node *newNode = d->head;  
    int sizess=d->size;  
    for (int i = 0; i <sizess; i++) {
      if(pred_func(newNode->data)){
        if (newNode==d->head) {
          pop_front(d);           
        } else if (newNode==d->tail) {
          pop_back(d);
        } else {
          newNode->prev->next = newNode->next;
          newNode->next->prev = newNode->prev;
          //free_func(newNode->data);
          free(newNode);
          d->size--;          
        }
        free_func(newNode->data);
        number++;
      } 
        newNode=newNode->next;
      
      
    }  
    return number;
}


/** is_empty
  *
  * Checks to see if the deque is empty.
  *
  * @param d a pointer to the deque structure
  * @return 1 if the deque is indeed empty, or 0 otherwise.
  */
int is_empty(deque *d)
{
    if (d==NULL) {
      return 0;
    }
    /// @note an empty deque should have a size of zero and head points to NULL.
    if ((d -> size) == 0 && (d -> head == NULL)) {
      return 1;
    } else {
      return 0;
    }
}

/** empty_deque
  *
  * Empties the deque. After this is called, the deque should be empty.
  * This does not free the deque struct itself, just all nodes and data within.
  *
  * @param d a pointer to the deque structure
  * @param free_func function used to free the nodes' data.
  */
void empty_deque(deque *d, deque_op free_func)
{
    /// @todo Implement
    /// @note Free all of the nodes, not the deque structure itself.
    /// @note do not free the deque structure itself.
    if(d==NULL||!d -> size) {
      return;
    }
    node *newNode = d ->head;
    node *nextNode = newNode ->next;
    for (int i=0; i<d->size;i++) {
      free_func(newNode->data);
      free(newNode);
      newNode = nextNode;
      if (i<d->size -1) {
        nextNode = newNode->next;
      }
    } 
    d->head = NULL;
    d->tail = NULL;
    d->size = 0;
}

/** traverse
  *
  * Traverses the deque, calling a function on each node's data.
  *
  * @param d a pointer to the deque structure
  * @param do_func a function that does something to each node's data.
  */
void traverse(deque *d, deque_op do_func)
{
    /// @todo Implement
    node *newNode = d -> head;
    for (int i =0; i< d->size; i++) {
      do_func(newNode ->data);
      newNode = newNode -> next;
    }
}
